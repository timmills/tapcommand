import { AppProviders } from './app/providers';

const App = () => {
  return <AppProviders />;
};

export default App;
