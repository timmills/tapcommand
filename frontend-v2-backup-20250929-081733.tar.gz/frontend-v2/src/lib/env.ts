const ensureEnv = (key: string, fallback?: string): string => {
  const value = import.meta.env[key as keyof ImportMetaEnv];
  if (typeof value === 'string' && value.length > 0) {
    return value;
  }
  if (fallback !== undefined) {
    return fallback;
  }
  console.warn(`Environment variable ${key} is not set; falling back to empty string.`);
  return '';
};

export const API_BASE_URL = ensureEnv('VITE_API_BASE_URL', 'http://localhost:8000');
export const WS_BASE_URL = ensureEnv('VITE_WS_BASE_URL');
