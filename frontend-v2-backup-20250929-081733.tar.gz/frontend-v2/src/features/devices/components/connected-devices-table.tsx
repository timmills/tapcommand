import type { ManagedDevice } from '@/types';
import { formatRelativeTime } from '@/utils/datetime';

interface ConnectedDevice {
  id: string;
  deviceName: string;
  controllerName: string;
  controllerHostname: string;
  controllerLocation: string;
  portNumber: number;
  status: 'online' | 'offline';
  updatedAt: string;
}

interface ConnectedDevicesTableProps {
  controllers: ManagedDevice[];
}

const buildConnectedDevices = (controllers: ManagedDevice[]): ConnectedDevice[] => {
  return controllers.flatMap((controller) => {
    return controller.ir_ports
      .filter((port) => port.is_active)
      .map((port) => ({
        id: `${controller.id}-${port.id ?? port.port_number}`,
        deviceName: port.connected_device_name || `Port ${port.port_number}`,
        controllerName: controller.device_name ?? controller.hostname,
        controllerHostname: controller.hostname,
        controllerLocation: controller.location ?? '—',
        portNumber: port.port_number,
        status: controller.is_online ? 'online' : 'offline',
        updatedAt: controller.last_seen,
      }));
  });
};

export const ConnectedDevicesTable = ({ controllers }: ConnectedDevicesTableProps) => {
  const connectedDevices = buildConnectedDevices(controllers);

  if (connectedDevices.length === 0) {
    return (
      <div className="rounded-md border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
        No connected devices reported yet. Assign IR libraries to controller ports to see devices here.
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Device</th>
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Controller</th>
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Port</th>
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Location</th>
            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Last seen</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {connectedDevices.map((device) => (
            <tr key={device.id} className="hover:bg-slate-50/70">
              <td className="px-4 py-3 align-top">
                <div className="text-sm font-medium text-slate-900">{device.deviceName}</div>
              </td>
              <td className="px-4 py-3 align-top text-sm text-slate-600">
                <div>{device.controllerName}</div>
                <div className="text-xs text-slate-500">{device.controllerHostname}</div>
              </td>
              <td className="px-4 py-3 align-top text-sm text-slate-600">Port {device.portNumber}</td>
              <td className="px-4 py-3 align-top text-sm text-slate-600">{device.controllerLocation}</td>
              <td className="px-4 py-3 align-top text-sm text-slate-600">{formatRelativeTime(device.updatedAt)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
