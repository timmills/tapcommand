import { apiClient } from '@/lib/axios';
import type { ManagedDevice } from '@/types';

export const fetchManagedDevices = async (): Promise<ManagedDevice[]> => {
  const response = await apiClient.get<ManagedDevice[]>('/api/v1/management/managed');
  return response.data;
};
