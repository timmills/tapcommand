export const SettingsPage = () => {
  return (
    <section className="space-y-6">
      <header>
        <h2 className="text-lg font-semibold text-slate-900">Settings & diagnostics</h2>
        <p className="text-sm text-slate-500">
          Centralise future configuration surfaces such as Wi-Fi credentials, device tags, and channel presets.
        </p>
      </header>

      <div className="rounded-lg border border-dashed border-slate-300 bg-white p-8 text-sm text-slate-600">
        <p>
          The next iteration will surface configurable settings and deeper diagnostics. For now this area acts as a
          placeholder so the new navigation structure matches the existing product map.
        </p>
      </div>
    </section>
  );
};
