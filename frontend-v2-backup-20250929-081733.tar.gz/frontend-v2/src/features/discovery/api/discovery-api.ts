import { apiClient } from '@/lib/axios';
import type { DiscoveredDevice } from '@/types';

interface DiscoveryServiceResponse {
  devices: DiscoveredDevice[];
}

export const fetchDiscoveredDevices = async (): Promise<DiscoveredDevice[]> => {
  const response = await apiClient.get<DiscoveryServiceResponse>('/api/v1/devices/discovery/devices');
  return response.data.devices ?? [];
};

export const startDiscovery = async (): Promise<void> => {
  await apiClient.get('/api/v1/devices/discovery/start');
};

export const stopDiscovery = async (): Promise<void> => {
  await apiClient.get('/api/v1/devices/discovery/stop');
};
